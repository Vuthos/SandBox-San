# Arquitetura — Editor de Mapas San v1.1

## Fluxo principal

```text
index.html
   ↓
core/model + core/state
   ↓
editor tools / UI
   ↓
SAN Map JSON
   ↓
game runtime
   ↓
renderer
```

## Modelo de mapa

O JSON do mapa continua usando a versão de esquema 7. Entre os grupos principais estão:

- `grid`: tamanho da grade;
- `spawn` e `goal`: início e chegada;
- `walls`: paredes;
- `enemies`: inimigos parados, patrulha e guiados;
- `portals`: pares de portais;
- `checkpoints`: pontos de renascimento;
- `keyDoors`: chaves e portas;
- `buttons`: botões ligados a objetos;
- `coins`: moedas obrigatórias;
- `settings`: comportamento de reset após morte.

## Responsabilidades

### core/model.js
Normaliza mapas, preserva compatibilidade e contém utilidades de coordenadas/grade.

### core/state.js
Centraliza o estado mutável da sessão, do editor e da simulação.

### core/history.js
Undo, redo, autosave e snapshots.

### editor/tools.js
Criação e remoção de objetos e rotas pelo Canvas.

### editor/selection.js
Seleção e propriedades editáveis.

### editor/clipboard.js
Seleção múltipla, duplicação, cópia e colagem.

### editor/viewport.js
Zoom, pan e seleção retangular.

### editor/validation.js
Validação estrutural e análise aproximada de alcançabilidade.

### editor/templates.js
Templates internos e templates locais.

### game/enemies.js
Simulação dos tipos de inimigo e seus movimentos.

### game/player.js
Movimento do jogador, portais, itens, checkpoints, botões e respawn.

### game/collision.js
Colisões com limites, paredes e portas.

### game/runtime.js
Inicialização do teste e loop de atualização.

### render/renderer.js
Desenha grade, objetos, rotas, jogador, inimigos e tela de vitória.

### ui/inspector.js
Configurações do mapa e propriedades exibidas no painel lateral.

### ui/actions.js
Ações de arquivo, atalhos e troca entre editar/testar.

## Regra para futuras versões

Ao adicionar uma função nova, primeiro escolha a responsabilidade dela. Por exemplo:

- pintura/cenário → `src/editor/` + `src/render/`;
- aparência de paredes → `src/render/` e modelo do mapa;
- novo comportamento de inimigo → `src/game/enemies.js`;
- novo controle do Inspector → `src/ui/inspector.js`;
- nova regra de validação → `src/editor/validation.js`.

O objetivo é impedir que `index.html` volte a carregar a lógica inteira do projeto.
