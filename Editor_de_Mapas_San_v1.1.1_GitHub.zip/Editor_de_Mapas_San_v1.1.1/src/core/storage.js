'use strict';

// Restauração de rascunhos locais de versões anteriores.
function restoreDraft(){
  try{
    const s=localStorage.getItem('sanMapEditorV11Draft') || localStorage.getItem('sanMapEditorV7Draft') || localStorage.getItem('sanMapEditorV6Draft') || localStorage.getItem('sanMapEditorV5Draft');
    if(s){ normalizeMap(JSON.parse(s)); return true; }
  }catch{}
  return false;
}
