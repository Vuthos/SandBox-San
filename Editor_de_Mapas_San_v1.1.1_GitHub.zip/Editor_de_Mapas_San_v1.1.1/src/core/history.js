'use strict';

// Histórico, autosave e contagem de objetos.
function snapshot(){ return JSON.stringify(map); }
function safeAutosave(){
  try{ localStorage.setItem('sanMapEditorV11Draft', snapshot()); autosaveLabel.textContent='Rascunho local: salvo automaticamente'; }
  catch{ autosaveLabel.textContent='Rascunho local: indisponível neste navegador'; }
}
function updateHistoryButtons(){ $('undoBtn').disabled=historyIndex<=0; $('redoBtn').disabled=historyIndex>=history.length-1; }
function updateStats(){ stats.textContent=`${objectCount()} objetos • ${map.enemies.length} inimigos • ${gridCols()}×${gridRows()}`; }
function commit(){
  if(historyLock) return;
  const s = snapshot();
  if(history[historyIndex]===s) return;
  history=history.slice(0,historyIndex+1);
  history.push(s);
  if(history.length>80) history.shift(); else historyIndex++;
  if(history.length===80) historyIndex=79;
  safeAutosave(); updateHistoryButtons(); updateStats();
}
function resetHistory(){ history=[snapshot()]; historyIndex=0; updateHistoryButtons(); safeAutosave(); updateStats(); }
function restoreSnapshot(s){
  historyLock=true;
  normalizeMap(JSON.parse(s));
  syncDocumentControls();
  clearPending(); clearSelection();
  draw(); updateStats();
  historyLock=false;
}
function undo(){ if(historyIndex<=0) return; historyIndex--; restoreSnapshot(history[historyIndex]); updateHistoryButtons(); setStatus('Desfeito.'); }
function redo(){ if(historyIndex>=history.length-1) return; historyIndex++; restoreSnapshot(history[historyIndex]); updateHistoryButtons(); setStatus('Refeito.'); }

function objectCount(){
  return map.walls.length+map.enemies.length+map.portals.length+map.checkpoints.length+
    map.keyDoors.length+map.buttons.length+map.coins.length+2;
}
