'use strict';

// Modelo do mapa, geometria e compatibilidade de formato SAN Map.
function gridCols(){ return map.grid?.cols || 30; }
function gridRows(){ return map.grid?.rows || 18; }
function canvasW(){ return gridCols()*CELL; }
function canvasH(){ return gridRows()*CELL; }
function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
function maxX(){ return canvas.width; }
function maxY(){ return canvas.height; }
function resizeCanvas(){ canvas.width = canvasW(); canvas.height = canvasH(); }
function insideCell(c,r){ return c>=0 && r>=0 && c<gridCols() && r<gridRows(); }
function clampPointToCanvas(p){
  return { x: clamp(Number(p.x)||0, 0, Math.max(0, canvasW())), y: clamp(Number(p.y)||0, 0, Math.max(0, canvasH())) };
}

function freshMap(){
  return{
    version:7,
    meta:{name:'Nova fase'},
    grid:{cols:30, rows:18},
    settings:{resetCollectiblesOnDeath:false,resetLogicOnDeath:false,resetEnemiesOnDeath:false},
    spawn:{c:1,r:8},goal:{c:28,r:8},
    walls:[],enemies:[],portals:[],checkpoints:[],keyDoors:[],buttons:[],coins:[]
  };
}
function nextId(arr){ return arr.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1; }
function normAngle(a){ a=Number(a)||0; return ((a%360)+360)%360; }
function sameCell(a,c,r){ return !!a && a.c===c && a.r===r; }
function cellCenter(c,r){ return {x:(c+.5)*CELL, y:(r+.5)*CELL}; }
function snap(v){ const s=Math.max(1,Number(snapSelect.value)||1); return Math.round(v/s)*s; }
function snapPoint(p){ return clampPointToCanvas({x:snap(p.x), y:snap(p.y)}); }

function wallContains(w,c,r){ return c>=w.c&&r>=w.r&&c<w.c+w.w&&r<w.r+w.h; }
function wallAt(c,r){ return map.walls.find(w=>wallContains(w,c,r)); }
function pointInCell(x,y,c,r){ return Math.floor(x/CELL)===c&&Math.floor(y/CELL)===r; }
function enemyAnchor(e){ return e.type==='guided'?e.route[0]:e.type==='static'?{x:e.x,y:e.y}:e.start; }
function enemyAtPoint(x,y){ return map.enemies.find(e=>{ const p=enemyAnchor(e); return p && Math.hypot(p.x-x,p.y-y)<=16; }); }
function targetKey(t){ return !t ? '' : `${t.kind}:${t.id}`; }

function fitMapToGrid(){
  const cols = gridCols(), rows = gridRows(), wpx = canvasW(), hpx = canvasH();

  map.spawn.c = clamp(map.spawn.c, 0, cols-1);
  map.spawn.r = clamp(map.spawn.r, 0, rows-1);
  map.goal.c  = clamp(map.goal.c, 0, cols-1);
  map.goal.r  = clamp(map.goal.r, 0, rows-1);

  map.walls = map.walls.filter(w => w.c < cols && w.r < rows).map(w => ({
    ...w,
    c: clamp(w.c,0,cols-1), r: clamp(w.r,0,rows-1),
    w: clamp(w.w,1,cols-clamp(w.c,0,cols-1)),
    h: clamp(w.h,1,rows-clamp(w.r,0,rows-1))
  }));

  const keepCellObj = obj => insideCell(obj.c,obj.r);
  map.checkpoints = map.checkpoints.filter(keepCellObj);
  map.coins = map.coins.filter(keepCellObj);
  map.portals = map.portals.filter(p => insideCell(p.a.c,p.a.r) && insideCell(p.b.c,p.b.r));
  map.keyDoors = map.keyDoors.filter(k => insideCell(k.key.c,k.key.r) && insideCell(k.door.c,k.door.r));
  map.buttons = map.buttons.filter(b => insideCell(b.pos.c,b.pos.r));

  map.enemies = map.enemies.map(e => {
    if(e.type==='static'){
      return {...e, ...clampPointToCanvas({x:e.x,y:e.y})};
    }
    if(e.type==='guided'){
      const route = (e.route||[]).map(clampPointToCanvas);
      return {...e, route: route.length ? route : [{x:64,y:64},{x:160,y:64}]};
    }
    return {
      ...e,
      start: clampPointToCanvas(e.start||{x:64,y:64}),
      end: clampPointToCanvas(e.end||{x:160,y:64}),
      angle: normAngle(e.angle)
    };
  });

  const enemyIds = new Set(map.enemies.map(e=>e.id));
  const wallIds  = new Set(map.walls.map(w=>w.id));
  const doorIds  = new Set(map.keyDoors.map(k=>k.id));
  map.buttons = map.buttons.filter(b => {
    if(!b.target) return false;
    if(b.target.kind==='enemy') return enemyIds.has(b.target.id);
    if(b.target.kind==='wall') return wallIds.has(b.target.id);
    if(b.target.kind==='door') return doorIds.has(b.target.id);
    return false;
  });
}

function normalizeMap(data){
  const base = freshMap();
  const out = Object.assign(base, data||{});
  out.meta = Object.assign(base.meta, data?.meta||{});
  out.settings = Object.assign(base.settings, data?.settings||{});
  out.grid = Object.assign(base.grid, data?.grid||{});
  out.grid.cols = clamp(Number(out.grid.cols)||30, 10, 120);
  out.grid.rows = clamp(Number(out.grid.rows)||18, 8, 80);
  for(const k of ['walls','enemies','portals','checkpoints','keyDoors','buttons','coins']) out[k]=Array.isArray(out[k])?out[k]:[];
  out.spawn = out.spawn || {c:1,r:8};
  out.goal  = out.goal  || {c:28,r:8};

  out.walls = out.walls.map((w,i)=>({
    id:Number(w.id)||i+1,
    c:Number(w.c)||0, r:Number(w.r)||0,
    w:Math.max(1,Number(w.w)||1), h:Math.max(1,Number(w.h)||1)
  }));

  out.enemies = out.enemies.map((e,i)=>{
    const id=Number(e.id)||i+1;
    if(e.type==='guided'&&Array.isArray(e.route)){
      const route = e.route.map(p=>({x:Number(p.x)||0, y:Number(p.y)||0}));
      return {id,type:'guided',speed:Math.max(1,Number(e.speed)||90),route:route.length?route:[{x:64,y:64},{x:192,y:64}]};
    }
    if(e.type==='static'){
      const x = Number.isFinite(Number(e.x)) ? Number(e.x) : ((Number(e.c)||0)+.5)*CELL;
      const y = Number.isFinite(Number(e.y)) ? Number(e.y) : ((Number(e.r)||0)+.5)*CELL;
      return {id,type:'static',x,y};
    }
    const sx=Number.isFinite(Number(e.start?.x))?Number(e.start.x):(Number.isFinite(Number(e.x))?Number(e.x):((Number(e.c)||0)+.5)*CELL);
    const sy=Number.isFinite(Number(e.start?.y))?Number(e.start.y):(Number.isFinite(Number(e.y))?Number(e.y):((Number(e.r)||0)+.5)*CELL);
    const angle=Number.isFinite(Number(e.angle))?normAngle(e.angle):(e.type==='vertical'?90:0);
    const sp=Math.max(1,Number(e.speed)||90);
    const ex=Number.isFinite(Number(e.end?.x))?Number(e.end.x):sx+Math.cos(angle*Math.PI/180)*CELL*4;
    const ey=Number.isFinite(Number(e.end?.y))?Number(e.end.y):sy+Math.sin(angle*Math.PI/180)*CELL*4;
    return {id,type:'moving',mode:e.mode==='free'?'free':'patrol',speed:sp,start:{x:sx,y:sy},end:{x:ex,y:ey},angle};
  });

  out.buttons = out.buttons.map((b,i)=>({
    id:Number(b.id)||i+1, pos:b.pos||{c:0,r:0}, target:b.target||null
  }));

  map = out;
  resizeCanvas();
  fitMapToGrid();
  map.version = 7;
  return map;
}

