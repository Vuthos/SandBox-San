'use strict';

// Controles do Inspector e tamanho do mapa.
function syncDocumentControls(){
  levelName.value=map.meta?.name||'Nova fase';
  resetCollectibles.checked=!!map.settings.resetCollectiblesOnDeath;
  resetLogic.checked=!!map.settings.resetLogicOnDeath;
  resetEnemies.checked=!!map.settings.resetEnemiesOnDeath;
  mapColsInput.value = gridCols();
  mapRowsInput.value = gridRows();
}
levelName.addEventListener('change',()=>{ map.meta.name=levelName.value.trim()||'Nova fase'; levelName.value=map.meta.name; commit(); });
resetCollectibles.onchange=()=>{ map.settings.resetCollectiblesOnDeath=resetCollectibles.checked; commit(); };
resetLogic.onchange=()=>{ map.settings.resetLogicOnDeath=resetLogic.checked; commit(); };
resetEnemies.onchange=()=>{ map.settings.resetEnemiesOnDeath=resetEnemies.checked; commit(); };
$('applyMapSize').onclick=()=>{
  const newCols = clamp(Number(mapColsInput.value)||30, 10, 120);
  const newRows = clamp(Number(mapRowsInput.value)||18, 8, 80);
  const shrinking = newCols < gridCols() || newRows < gridRows();
  if(shrinking){
    if(!confirm('Diminuir o mapa pode remover ou ajustar objetos fora da nova área. Deseja continuar?')){ syncDocumentControls(); return; }
  }
  map.grid.cols = newCols;
  map.grid.rows = newRows;
  resizeCanvas();
  fitMapToGrid();
  clearSelection();
  commit();
  draw();
  setStatus(`Mapa redimensionado para ${newCols}×${newRows}.`);
};
