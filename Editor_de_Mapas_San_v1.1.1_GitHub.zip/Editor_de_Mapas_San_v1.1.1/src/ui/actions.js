'use strict';

// Ações globais: modos, arquivos JSON e atalhos de teclado.
$('editBtn').onclick=()=>setMode('edit');
$('testBtn').onclick=()=>setMode('test');
$('resetBtn').onclick=()=>{ if(mode==='test') startTest(); else { clearPending(); clearSelection(); draw(); setStatus('Edição limpa de seleções temporárias.'); } };
$('undoBtn').onclick=undo; $('redoBtn').onclick=redo;
$('newBtn').onclick=()=>{
  if(confirm('Criar um mapa novo? Alterações não exportadas continuarão apenas no histórico desta sessão.')){
    map=freshMap(); resizeCanvas(); deaths=0; clearPending(); clearSelection(); syncDocumentControls(); resetHistory(); setMode('edit'); draw(); setStatus('Novo mapa criado.');
  }
};
$('openBtn').onclick=()=>fileInput.click();
fileInput.onchange=()=>{
  const f=fileInput.files?.[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{
    try{
      normalizeMap(JSON.parse(String(r.result)));
      clearPending(); clearSelection(); syncDocumentControls(); resetHistory(); setMode('edit'); draw(); setStatus('Mapa carregado: '+f.name);
    }catch(e){ setStatus('Erro ao abrir JSON: '+e.message); }
    fileInput.value='';
  };
  r.readAsText(f,'utf-8');
};
$('downloadBtn').onclick=()=>{
  const json=JSON.stringify(map,null,2); jsonArea.value=json;
  if(!confirm('Deseja baixar esta fase em JSON?')) return;
  const blob=new Blob([json],{type:'application/json'}), url=URL.createObjectURL(blob), a=document.createElement('a');
  const safe=(map.meta.name||'mapa_san').replace(/[^\w\-áéíóúãõç ]/gi,'').trim().replace(/\s+/g,'_')||'mapa_san';
  a.href=url; a.download=safe+'.json'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); setStatus('JSON salvo.');
};
$('generateBtn').onclick=()=>{ jsonArea.value=JSON.stringify(map,null,2); setStatus('Caixa JSON atualizada.'); };
$('loadTextBtn').onclick=()=>{
  try{
    normalizeMap(JSON.parse(jsonArea.value));
    clearPending(); clearSelection(); syncDocumentControls(); resetHistory(); setMode('edit'); draw(); setStatus('JSON carregado da caixa.');
  }catch(e){ setStatus('JSON inválido: '+e.message); }
};

addEventListener('keydown',ev=>{
  const typing=['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName);
  if((ev.ctrlKey||ev.metaKey)&&ev.key.toLowerCase()==='z'){ ev.preventDefault(); ev.shiftKey?redo():undo(); return; }
  if((ev.ctrlKey||ev.metaKey)&&ev.key.toLowerCase()==='y'){ ev.preventDefault(); redo(); return; }
  if(ev.key==='Delete'&&!typing&&mode==='edit'&&selected){ deleteSelected(); return; }
  if(mode!=='test'||typing) return;
  const k=ev.key.toLowerCase(); keys[k]=true; if(k.startsWith('arrow')) ev.preventDefault();
});
addEventListener('keyup',ev=>keys[ev.key.toLowerCase()]=false);

const oldDownload = $('downloadBtn').onclick;
$('downloadBtn').onclick = ()=>{ runValidation(false); oldDownload(); };
const oldTest = $('testBtn').onclick;
$('testBtn').onclick = ()=>{ runValidation(false); oldTest(); };

addEventListener('keydown', ev=>{
  const typing=['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName);
  if(typing) return;
  if((ev.ctrlKey||ev.metaKey) && ev.key.toLowerCase()==='c'){ ev.preventDefault(); copySelectionToClipboard(); }
  if((ev.ctrlKey||ev.metaKey) && ev.key.toLowerCase()==='v'){ ev.preventDefault(); pasteClipboard(1); }
  if((ev.ctrlKey||ev.metaKey) && ev.key.toLowerCase()==='d'){ ev.preventDefault(); duplicateSelection(); }
});
