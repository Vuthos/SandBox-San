'use strict';

// Ponto de entrada da aplicação.
restoreDraft();
normalizeMap(map);
syncDocumentControls();
resetHistory();
updateGuideButtons();
updateStatus();
refreshTemplates();
applyZoom();
draw();

document.querySelectorAll('.tool').forEach(btn=>btn.classList.toggle('active',btn.dataset.tool===tool));
