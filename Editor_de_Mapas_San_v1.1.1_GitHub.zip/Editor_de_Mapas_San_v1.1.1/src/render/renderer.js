'use strict';

// Renderização do mapa, rotas, objetos e modo de teste.
function setStatus(s){ status.textContent=s; }
function updateStatus(){
  if(mode==='edit'){
    const names={select:'Selecionar / editar',wall:'Parede',spawn:'Início',goal:'Chegada',checkpoint:'Checkpoint',
      static:'Inimigo parado',horizontal:'Patrulha horizontal',vertical:'Patrulha vertical',directional:'Patrulha X↔Y',
      guided:'Inimigo guiado',portal:'Portal',keydoor:'Chave + porta',button:'Botão → objeto',coin:'Moeda',erase:'Apagar'};
    let tail=''; if(pendingPatrol) tail=' • escolha o ponto Y'; if(pendingGuide) tail=` • ${pendingGuide.length} ponto(s) na rota`;
    setStatus(`Ferramenta: ${names[tool]}${tail}`);
  }else{
    setStatus(won?`Fase concluída • ${deaths} morte(s)`:`Teste • ${deaths} morte(s) • moedas ${collectedCoins.size}/${map.coins.length}${activeCheckpoint?' • CP '+activeCheckpoint:''}`);
  }
}
function grid(){
  ctx.strokeStyle='#dedede'; ctx.lineWidth=1;
  for(let c=0;c<=gridCols();c++){ ctx.beginPath(); ctx.moveTo(c*CELL,0); ctx.lineTo(c*CELL,canvas.height); ctx.stroke(); }
  for(let r=0;r<=gridRows();r++){ ctx.beginPath(); ctx.moveTo(0,r*CELL); ctx.lineTo(canvas.width,r*CELL); ctx.stroke(); }
}
function circle(x,y,r,fill,stroke='#111',lw=2){
  ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fillStyle=fill; ctx.fill(); ctx.strokeStyle=stroke; ctx.lineWidth=lw; ctx.stroke();
}
function line(points,color='#6b28a8',dash=[]){
  if(points.length<2) return;
  ctx.save(); ctx.strokeStyle=color; ctx.lineWidth=2; ctx.setLineDash(dash);
  ctx.beginPath(); ctx.moveTo(points[0].x,points[0].y); for(let i=1;i<points.length;i++) ctx.lineTo(points[i].x,points[i].y); ctx.stroke(); ctx.restore();
}
function drawRouteNodes(e){
  if(e.type!=='guided') return;
  e.route.forEach((p,i)=>{
    circle(p.x,p.y,i===0?8:5,i===0?'#8c3fd1':'#d7b0ee','#5b207e',1);
    ctx.fillStyle='#45205d'; ctx.font='bold 9px Arial'; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(String(i+1),p.x,p.y);
  });
}
function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height); ctx.fillStyle='#f4f4f4'; ctx.fillRect(0,0,canvas.width,canvas.height); grid();
  ctx.fillStyle='#91e57c'; ctx.fillRect(map.goal.c*CELL,map.goal.r*CELL,CELL,CELL);
  for(const cp of map.checkpoints){
    const r=rectCell(cp.c,cp.r); ctx.fillStyle=mode==='test'&&activeCheckpoint===cp.id?'#d7ed75':'#e8efaa'; ctx.fillRect(r.x,r.y,r.w,r.h);
  }
  for(const w of map.walls){
    if(mode==='test'&&!wallActive(w.id)) continue;
    const r=rectWall(w); ctx.fillStyle='#9a96c9'; ctx.fillRect(r.x,r.y,r.w,r.h);
    ctx.strokeStyle='#716d97'; ctx.lineWidth=1; ctx.strokeRect(r.x+.5,r.y+.5,r.w-1,r.h-1);
  }
  for(const kd of map.keyDoors){
    const kp=cellCenter(kd.key.c,kd.key.r), dr=rectCell(kd.door.c,kd.door.r);
    if(mode==='edit'||!collectedKeys.has(kd.id)) circle(kp.x,kp.y,9,'#ffd54a','#8d6500');
    if(mode==='edit'||!doorOpen(kd.id)) { ctx.fillStyle='#7356b8'; ctx.fillRect(dr.x+3,dr.y+2,dr.w-6,dr.h-4); }
  }
  for(const p of map.portals) for(const q of [p.a,p.b]){
    const z=cellCenter(q.c,q.r); circle(z.x,z.y,12,'#f39a34','#a85400',3); circle(z.x,z.y,6,'#4a2410','#ffbd66',1);
  }
  if(mode==='edit'&&pendingPortal){ const z=cellCenter(pendingPortal.c,pendingPortal.r); circle(z.x,z.y,12,'#ffc078','#a85400',2); }
  for(const b of map.buttons){
    const r=rectCell(b.pos.c,b.pos.r); ctx.fillStyle=mode==='test'&&disabledTargets.has(targetKey(b.target))?'#54777d':'#69d2dc'; ctx.fillRect(r.x+5,r.y+5,r.w-10,r.h-10);
  }
  for(const c of map.coins){
    if(mode==='test'&&collectedCoins.has(c.id)) continue;
    const p=cellCenter(c.c,c.r); circle(p.x,p.y,8,'#f6c945','#8d6500');
  }

  if(mode==='edit'){
    for(const e of map.enemies){
      if(e.type==='moving'){
        if(e.mode==='patrol'){ line([e.start,e.end],'#d34a4a',[6,4]); circle(e.start.x,e.start.y,9,'#e43d3d'); circle(e.end.x,e.end.y,4,'#ffb0b0','#9b2020',1); }
        else circle(e.start.x,e.start.y,9,'#e43d3d');
      }else if(e.type==='guided'){
        line(e.route,'#8d3cc6',[5,4]); drawRouteNodes(e);
      }else circle(e.x,e.y,9,'#e43d3d');
    }
    const s=cellCenter(map.spawn.c,map.spawn.r); circle(s.x,s.y,10,'#2b63ff');
    if(pendingPatrol){ circle(pendingPatrol.start.x,pendingPatrol.start.y,9,'#e43d3d'); }
    if(pendingGuide){ line(pendingGuide,'#8d3cc6',[5,4]); pendingGuide.forEach((p,i)=>circle(p.x,p.y,i===0?8:5,i===0?'#8c3fd1':'#d7b0ee','#5b207e',1)); }

    if(selected){
      if(selected.kind==='wall'){
        const w=map.walls.find(q=>q.id===selected.id);
        if(w){ const r=rectWall(w); ctx.save(); ctx.strokeStyle='#00a6ff'; ctx.lineWidth=3; ctx.setLineDash([7,4]); ctx.strokeRect(r.x+2,r.y+2,r.w-4,r.h-4); ctx.restore(); }
      }else{
        const e=map.enemies.find(q=>q.id===selected.id);
        if(e){
          const p=enemyAnchor(e); ctx.save(); ctx.strokeStyle='#00a6ff'; ctx.lineWidth=3; ctx.setLineDash([7,4]); ctx.strokeRect(p.x-14,p.y-14,28,28); ctx.restore();
          if(e.type==='guided') drawRouteNodes(e);
        }
      }
    }
  }else{
    for(const e of simEnemies) if(enemyActive(e.id)) circle(e.x,e.y,e.r,e.type==='guided'?'#8c3fd1':'#e43d3d');
    if(player) circle(player.x,player.y,player.r,'#2b63ff');
  }

  if(won){
    ctx.fillStyle='rgba(0,0,0,.62)'; ctx.fillRect(0,0,canvas.width,canvas.height); ctx.fillStyle='#fff'; ctx.font='bold 38px Segoe UI,Arial'; ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillText('FASE CONCLUÍDA',canvas.width/2,canvas.height/2-10); ctx.font='18px Segoe UI,Arial'; ctx.fillText(`${deaths} morte(s) • ${collectedCoins.size}/${map.coins.length} moedas`,canvas.width/2,canvas.height/2+28);
  }
}
