'use strict';

// Movimento, portais, coleta, checkpoints, botões e respawn do jogador.
function movePlayer(dx,dy){
  let ox=player.x,oy=player.y; player.x+=dx; if(playerBlocked(player.x,player.y,player.r)) player.x=ox;
  player.y+=dy; if(playerBlocked(player.x,player.y,player.r)) player.y=oy;
}
function portalCircle(pos){ const p=cellCenter(pos.c,pos.r); return {x:p.x,y:p.y,r:12}; }
function touchingPortal(o){ return map.portals.some(p=>circleCircle(o,portalCircle(p.a))||circleCircle(o,portalCircle(p.b))); }
function teleport(){
  if(player.portalLock){ if(touchingPortal(player)) return; player.portalLock=false; }
  for(const p of map.portals){
    const a=portalCircle(p.a), b=portalCircle(p.b);
    if(circleCircle(player,a)){ player.x=b.x; player.y=b.y; player.portalLock=true; return; }
    if(circleCircle(player,b)){ player.x=a.x; player.y=a.y; player.portalLock=true; return; }
  }
}
function collect(){
  for(const c of map.coins){
    if(collectedCoins.has(c.id)) continue;
    const p=cellCenter(c.c,c.r);
    if(circleCircle(player,{x:p.x,y:p.y,r:8})) collectedCoins.add(c.id);
  }
  for(const kd of map.keyDoors){
    if(collectedKeys.has(kd.id)) continue;
    const p=cellCenter(kd.key.c,kd.key.r);
    if(circleCircle(player,{x:p.x,y:p.y,r:9})) collectedKeys.add(kd.id);
  }
}
function checkpoint(){
  for(const cp of map.checkpoints){
    if(circleRect(player.x,player.y,player.r,rectCell(cp.c,cp.r))&&activeCheckpoint!==cp.id){
      activeCheckpoint=cp.id; respawnPoint=cellCenter(cp.c,cp.r);
    }
  }
}
function toggleTarget(t){ const k=targetKey(t); if(!k) return; disabledTargets.has(k)?disabledTargets.delete(k):disabledTargets.add(k); }
function buttons(){
  for(const b of map.buttons){
    const k='b:'+b.id, inside=circleRect(player.x,player.y,player.r,rectCell(b.pos.c,b.pos.r));
    if(inside&&!buttonInside.has(k)){ buttonInside.add(k); toggleTarget(b.target); }
    else if(!inside) buttonInside.delete(k);
  }
}
function respawn(){
  deaths++;
  if(map.settings.resetCollectiblesOnDeath){ collectedCoins=new Set(); collectedKeys=new Set(); }
  if(map.settings.resetLogicOnDeath){ disabledTargets=new Set(); buttonInside=new Set(); }
  if(map.settings.resetEnemiesOnDeath) simEnemies=buildSimEnemies();
  player.x=respawnPoint.x; player.y=respawnPoint.y; player.portalLock=false;
}
