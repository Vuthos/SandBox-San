'use strict';

// Ciclo de teste da fase e loop principal.
function setMode(next){
  mode=next; $('editBtn').classList.toggle('active',next==='edit'); $('testBtn').classList.toggle('active',next==='test');
  modeLabel.textContent=next==='edit'?'EDIÇÃO':'TESTE'; clearSelection();
  if(next==='test') startTest();
  else{ if(raf) cancelAnimationFrame(raf); raf=null; player=null; simEnemies=[]; won=false; updateStatus(); draw(); }
}

function startTest(){
  if(raf) cancelAnimationFrame(raf);
  won=false; collectedCoins=new Set(); collectedKeys=new Set(); disabledTargets=new Set(); buttonInside=new Set(); activeCheckpoint=null;
  respawnPoint=cellCenter(map.spawn.c,map.spawn.r);
  player={x:respawnPoint.x,y:respawnPoint.y,r:10,speed:175,portalLock:false};
  simEnemies=buildSimEnemies(); last=performance.now(); updateStatus(); raf=requestAnimationFrame(loop);
}

function update(dt){
  if(!player||won) return;
  let dx=0,dy=0; if(keys.w||keys.arrowup)dy--; if(keys.s||keys.arrowdown)dy++; if(keys.a||keys.arrowleft)dx--; if(keys.d||keys.arrowright)dx++;
  if(dx&&dy){ dx*=.70710678; dy*=.70710678; }
  movePlayer(dx*player.speed*dt,0); movePlayer(0,dy*player.speed*dt); teleport(); collect(); checkpoint(); buttons();

  for(const e of simEnemies){
    if(!enemyActive(e.id)) continue;
    updateEnemy(e,dt);
    if(circleCircle(player,e)){ respawn(); break; }
  }

  if(circleRect(player.x,player.y,player.r,rectCell(map.goal.c,map.goal.r))){
    if(collectedCoins.size>=map.coins.length){ won=true; updateStatus(); }
    else setStatus(`Chegada bloqueada: faltam ${map.coins.length-collectedCoins.size} moeda(s).`);
  }
}
function loop(now){ const dt=Math.min((now-last)/1000,.04); last=now; update(dt); draw(); raf=requestAnimationFrame(loop); }
