'use strict';

// Criação e movimentação dos inimigos.
function buildSimEnemies(){
  return map.enemies.map(e=>{
    if(e.type==='static') return{id:e.id,type:'static',x:e.x,y:e.y,r:9};
    if(e.type==='guided') return{id:e.id,type:'guided',x:e.route[0].x,y:e.route[0].y,r:9,speed:e.speed,route:e.route.map(p=>({...p})),next:1};
    if(e.mode==='free'){
      const rad=normAngle(e.angle)*Math.PI/180;
      return{id:e.id,type:'moving',mode:'free',x:e.start.x,y:e.start.y,r:9,speed:e.speed,angle:e.angle,vx:Math.cos(rad)*e.speed,vy:Math.sin(rad)*e.speed};
    }
    return{id:e.id,type:'moving',mode:'patrol',x:e.start.x,y:e.start.y,r:9,speed:e.speed,start:{...e.start},end:{...e.end},target:1};
  });
}

function moveTowardBudget(e,t,remaining){
  const dx=t.x-e.x,dy=t.y-e.y,d=Math.hypot(dx,dy);
  if(d<.001){ e.x=t.x; e.y=t.y; return {reached:true,remaining}; }
  if(remaining>=d){ e.x=t.x; e.y=t.y; return {reached:true,remaining:remaining-d}; }
  e.x+=dx/d*remaining; e.y+=dy/d*remaining;
  return {reached:false,remaining:0};
}

function updateGuidedEnemy(e,dt){
  if(e.route.length<2) return;
  let remaining=e.speed*dt;
  let guard=0;
  // Pode atravessar mais de um nó no mesmo frame sem perder o \"resto\" do movimento.
  while(remaining>0.0001 && guard++<128){
    const t=e.route[e.next%e.route.length];
    const step=moveTowardBudget(e,t,remaining);
    remaining=step.remaining;
    if(!step.reached) break;
    e.next=(e.next+1)%e.route.length;
  }
}

function updatePatrolEnemy(e,dt){
  let remaining=e.speed*dt;
  let guard=0;
  while(remaining>0.0001 && guard++<128){
    const t=e.target===1?e.end:e.start;
    const step=moveTowardBudget(e,t,remaining);
    remaining=step.remaining;
    if(!step.reached) break;
    e.target=e.target===1?0:1;
  }
}

function updateEnemy(e,dt){
  if(e.type==='static') return;
  if(e.type==='guided'){
    updateGuidedEnemy(e,dt);
    return;
  }
  if(e.mode==='patrol'){
    updatePatrolEnemy(e,dt);
    return;
  }
  if(e.mode==='free'){
    e.x+=e.vx*dt; e.y+=e.vy*dt;
    if(e.x-e.r<0){ e.x=e.r; e.vx=Math.abs(e.vx); }
    if(e.x+e.r>canvas.width){ e.x=canvas.width-e.r; e.vx=-Math.abs(e.vx); }
    if(e.y-e.r<0){ e.y=e.r; e.vy=Math.abs(e.vy); }
    if(e.y+e.r>canvas.height){ e.y=canvas.height-e.r; e.vy=-Math.abs(e.vy); }
  }
}
