'use strict';

// Colisões do jogador, paredes e portas.
function rectWall(w){ return {x:w.c*CELL,y:w.r*CELL,w:w.w*CELL,h:w.h*CELL}; }
function rectCell(c,r){ return {x:c*CELL,y:r*CELL,w:CELL,h:CELL}; }
function circleRect(cx,cy,r,q){
  const nx=Math.max(q.x,Math.min(cx,q.x+q.w)), ny=Math.max(q.y,Math.min(cy,q.y+q.h)), dx=cx-nx, dy=cy-ny;
  return dx*dx+dy*dy<r*r;
}
function circleCircle(a,b){ const dx=a.x-b.x,dy=a.y-b.y,rr=(a.r||9)+(b.r||9); return dx*dx+dy*dy<rr*rr; }
function doorOpen(id){ return collectedKeys.has(id)||disabledTargets.has('door:'+id); }
function wallActive(id){ return !disabledTargets.has('wall:'+id); }
function enemyActive(id){ return !disabledTargets.has('enemy:'+id); }
function playerBlocked(x,y,r){
  if(x-r<0||y-r<0||x+r>canvas.width||y+r>canvas.height) return true;
  for(const w of map.walls) if(wallActive(w.id)&&circleRect(x,y,r,rectWall(w))) return true;
  for(const kd of map.keyDoors) if(!doorOpen(kd.id)&&circleRect(x,y,r,rectCell(kd.door.c,kd.door.r))) return true;
  return false;
}
