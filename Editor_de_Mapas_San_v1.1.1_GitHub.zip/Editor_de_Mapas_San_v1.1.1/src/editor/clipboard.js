'use strict';

// Seleção múltipla, copiar/colar, duplicação e overlay de seleção.
function selectionKey(s){ return s ? `${s.kind}:${s.id}` : ''; }
function selectionArray(){
  if(selectedItems.length) return selectedItems.slice();
  return selected ? [selected] : [];
}
function isSelectedItem(kind,id){ return selectionArray().some(s=>s.kind===kind && s.id===id); }
function resetSelectionGroup(){ selectedItems = selected ? [selected] : []; }
const __oldClearSelection = clearSelection;
clearSelection = function(){ __oldClearSelection(); selectedItems = []; selectionRect = null; selectionStart = null; };
function ensurePrimarySelection(){
  const arr = selectionArray();
  selected = arr[0] || null;
  if(selected) selectedItems = arr;
}
function getObject(sel){
  if(!sel) return null;
  if(sel.kind==='wall') return map.walls.find(q=>q.id===sel.id) || null;
  if(sel.kind==='enemy') return map.enemies.find(q=>q.id===sel.id) || null;
  return null;
}
function normalizeSelectionGroup(){
  const arr = selectionArray().filter(s=>!!getObject(s));
  const uniq=[]; const seen=new Set();
  for(const s of arr){ const k=selectionKey(s); if(!seen.has(k)){ seen.add(k); uniq.push(s);} }
  selectedItems = uniq;
  selected = uniq[0] || null;
}
const __oldShowProperties = showProperties;
showProperties = function(){
  normalizeSelectionGroup();
  const arr = selectionArray();
  if(arr.length<=1){ return __oldShowProperties(); }
  props.classList.remove('hidden'); emptySelection.classList.add('hidden');
  wallProps.classList.add('hidden'); enemyProps.classList.add('hidden');
  staticProps.classList.add('hidden'); regularProps.classList.add('hidden'); guidedProps.classList.add('hidden');
  selectedInfo.textContent = `${arr.length} itens selecionados`;
};
selectAt = function(p){
  const w = wallAt(p.c,p.r); const e = enemyAtPoint(p.x,p.y); const hit = w ? {kind:'wall',id:w.id} : e ? {kind:'enemy',id:e.id} : null;
  if(selectToggleMode){
    if(hit){
      const k = selectionKey(hit);
      const idx = selectionArray().findIndex(s=>selectionKey(s)===k);
      if(idx>=0){ selectedItems = selectionArray().filter((_,i)=>i!==idx); }
      else { selectedItems = selectionArray().concat([hit]); selected = hit; }
      ensurePrimarySelection(); if(selected) showProperties(); else clearSelection(); draw();
    }else draw();
    return;
  }
  if(hit){ selected = hit; selectedItems=[hit]; showProperties(); draw(); return; }
  clearSelection(); draw();
};

function deleteSelectionSet(arr){
  const wallIds = new Set(arr.filter(s=>s.kind==='wall').map(s=>s.id));
  const enemyIds = new Set(arr.filter(s=>s.kind==='enemy').map(s=>s.id));
  if(wallIds.size){ map.walls = map.walls.filter(q=>!wallIds.has(q.id)); }
  if(enemyIds.size){ map.enemies = map.enemies.filter(q=>!enemyIds.has(q.id)); }
  map.buttons = map.buttons.filter(b=> !((b.target?.kind==='wall'&&wallIds.has(b.target.id)) || (b.target?.kind==='enemy'&&enemyIds.has(b.target.id))));
}
const __oldDeleteSelected = deleteSelected;
deleteSelected = function(){
  const arr = selectionArray();
  if(!arr.length) return __oldDeleteSelected();
  deleteSelectionSet(arr);
  clearSelection(); commit(); draw(); setStatus(arr.length>1 ? `${arr.length} objetos excluídos.` : 'Objeto excluído.');
};
$('deleteSelected').onclick = deleteSelected;

function cloneWall(w){ return {kind:'wall', data: JSON.parse(JSON.stringify(w))}; }
function cloneEnemy(e){ return {kind:'enemy', data: JSON.parse(JSON.stringify(e))}; }
function cloneSelection(){
  const out=[];
  for(const s of selectionArray()){
    const obj=getObject(s); if(!obj) continue;
    out.push(s.kind==='wall' ? cloneWall(obj) : cloneEnemy(obj));
  }
  return out;
}
function shiftEnemy(enemy, dx=CELL, dy=CELL){
  if(enemy.type==='static'){ enemy.x+=dx; enemy.y+=dy; }
  else if(enemy.type==='guided'){ enemy.route = enemy.route.map(p=>({x:p.x+dx,y:p.y+dy})); }
  else { enemy.start={x:enemy.start.x+dx,y:enemy.start.y+dy}; enemy.end={x:enemy.end.x+dx,y:enemy.end.y+dy}; }
}
function clampWallObj(w){
  w.c = clamp(w.c,0,gridCols()-1); w.r = clamp(w.r,0,gridRows()-1);
  w.w = clamp(w.w,1,gridCols()-w.c); w.h = clamp(w.h,1,gridRows()-w.r);
}
function clampEnemyObj(e){
  if(e.type==='static'){ const p=clampPointToCanvas({x:e.x,y:e.y}); e.x=p.x; e.y=p.y; }
  else if(e.type==='guided'){ e.route=(e.route||[]).map(clampPointToCanvas); }
  else { e.start=clampPointToCanvas(e.start); e.end=clampPointToCanvas(e.end); }
}
function pasteClipboard(offsetMultiplier=1){
  if(!clipboardItems.length){ setStatus('Nada copiado.'); return; }
  const newSel=[];
  for(const item of clipboardItems){
    if(item.kind==='wall'){
      const w = JSON.parse(JSON.stringify(item.data));
      w.id = nextId(map.walls); w.c += offsetMultiplier; w.r += offsetMultiplier; clampWallObj(w); map.walls.push(w); newSel.push({kind:'wall',id:w.id});
    }else if(item.kind==='enemy'){
      const e = JSON.parse(JSON.stringify(item.data));
      e.id = nextId(map.enemies); shiftEnemy(e, CELL*offsetMultiplier, CELL*offsetMultiplier); clampEnemyObj(e); map.enemies.push(e); newSel.push({kind:'enemy',id:e.id});
    }
  }
  selectedItems=newSel; selected=newSel[0]||null; commit(); showProperties(); draw(); setStatus(`${newSel.length} item(ns) colado(s).`);
}
function copySelectionToClipboard(){
  clipboardItems = cloneSelection();
  setStatus(clipboardItems.length ? `${clipboardItems.length} item(ns) copiado(s).` : 'Nenhum item selecionado para copiar.');
}
function duplicateSelection(){
  clipboardItems = cloneSelection();
  pasteClipboard(1);
}

const __baseDraw = draw;
draw = function(){
  __baseDraw();
  if(mode==='edit'){
    const arr = selectionArray();
    if(arr.length>1){
      ctx.save(); ctx.strokeStyle='#00d4ff'; ctx.lineWidth=2; ctx.setLineDash([6,4]);
      for(const s of arr){
        const obj = getObject(s); if(!obj) continue;
        if(s.kind==='wall'){
          const r=rectWall(obj); ctx.strokeRect(r.x+3,r.y+3,r.w-6,r.h-6);
        }else if(s.kind==='enemy'){
          const p=enemyAnchor(obj); if(p) ctx.strokeRect(p.x-14,p.y-14,28,28);
        }
      }
      ctx.restore();
    }
    if(selectionRect){
      const x=Math.min(selectionRect.x1,selectionRect.x2), y=Math.min(selectionRect.y1,selectionRect.y2), w=Math.abs(selectionRect.x2-selectionRect.x1), h=Math.abs(selectionRect.y2-selectionRect.y1);
      ctx.save(); ctx.fillStyle='rgba(0,170,255,.10)'; ctx.strokeStyle='rgba(0,170,255,.95)'; ctx.setLineDash([8,5]); ctx.lineWidth=2; ctx.fillRect(x,y,w,h); ctx.strokeRect(x,y,w,h); ctx.restore();
    }
  }
};

duplicateBtn && (duplicateBtn.onclick=duplicateSelection);
copyBtn && (copyBtn.onclick=copySelectionToClipboard);
pasteBtn && (pasteBtn.onclick=()=>pasteClipboard(1));
duplicateSelectedBtn && (duplicateSelectedBtn.onclick=duplicateSelection);
copySelectedBtn && (copySelectedBtn.onclick=copySelectionToClipboard);
