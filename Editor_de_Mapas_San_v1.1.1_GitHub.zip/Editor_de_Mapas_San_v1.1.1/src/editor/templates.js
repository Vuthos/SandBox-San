'use strict';

// Templates internos e templates locais do usuário.
function builtInTemplates(){
  const a=freshMap(); a.meta.name='Arena básica'; a.grid={cols:20,rows:12}; a.spawn={c:1,r:5}; a.goal={c:18,r:5}; a.coins=[{id:1,c:10,r:5}];
  const c=freshMap(); c.meta.name='Corredor com checkpoint'; c.grid={cols:28,rows:10}; c.spawn={c:1,r:4}; c.goal={c:26,r:4}; c.checkpoints=[{id:1,c:12,r:4}]; c.walls=[{id:1,c:0,r:2,w:28,h:1},{id:2,c:0,r:7,w:28,h:1}]; c.enemies=[{id:1,type:'moving',mode:'patrol',speed:90,start:{x:9*CELL,y:4.5*CELL},end:{x:18*CELL,y:4.5*CELL},angle:0}];
  const l=freshMap(); l.meta.name='Labirinto curto'; l.grid={cols:24,rows:14}; l.spawn={c:1,r:1}; l.goal={c:22,r:12}; l.walls=[{id:1,c:3,r:0,w:1,h:10},{id:2,c:6,r:4,w:1,h:10},{id:3,c:9,r:0,w:1,h:10},{id:4,c:12,r:4,w:1,h:10},{id:5,c:15,r:0,w:1,h:10},{id:6,c:18,r:4,w:1,h:10}];
  return [{key:'builtin:arena',name:'Arena básica',map:a},{key:'builtin:corridor',name:'Corredor com checkpoint',map:c},{key:'builtin:maze',name:'Labirinto curto',map:l}];
}
function customTemplates(){
  try{ return JSON.parse(localStorage.getItem('sanMapEditorV11Templates') || localStorage.getItem('sanMapEditorV7Templates') || '[]'); }catch{ return []; }
}
function saveCustomTemplates(list){ localStorage.setItem('sanMapEditorV11Templates', JSON.stringify(list)); }
function refreshTemplates(){
  templatesCache = [...builtInTemplates(), ...customTemplates()];
  if(!templateSelect) return;
  templateSelect.innerHTML = templatesCache.map(t=>`<option value="${t.key}">${t.name}</option>`).join('');
}
function loadTemplateByKey(key){
  const item = templatesCache.find(t=>t.key===key); if(!item) return;
  map = JSON.parse(JSON.stringify(item.map));
  normalizeMap(map); resizeCanvas(); fitMapToGrid(); syncDocumentControls(); clearPending(); clearSelection(); resetHistory(); setMode('edit'); draw(); runValidation(false); setStatus(`Template carregado: ${item.name}`);
}
refreshTemplates();
loadTemplateBtn && (loadTemplateBtn.onclick=()=>{ if(templateSelect.value) loadTemplateByKey(templateSelect.value); });
saveTemplateBtn && (saveTemplateBtn.onclick=()=>{
  const name = prompt('Nome do template:', map.meta?.name || 'Meu template');
  if(!name) return;
  const list = customTemplates();
  const key = 'custom:'+Date.now();
  list.push({key,name,map:JSON.parse(JSON.stringify(map))});
  saveCustomTemplates(list); refreshTemplates(); templateSelect.value=key; setStatus('Template salvo localmente.');
});
deleteTemplateBtn && (deleteTemplateBtn.onclick=()=>{
  const key = templateSelect.value; if(!key || !key.startsWith('custom:')){ setStatus('Selecione um template próprio para excluir.'); return; }
  const list = customTemplates().filter(t=>t.key!==key); saveCustomTemplates(list); refreshTemplates(); setStatus('Template excluído.');
});
