'use strict';

// Validação estrutural e análise de alcançabilidade do mapa.
function validateMap(){
  const errors=[], warnings=[];
  if(!insideCell(map.spawn.c,map.spawn.r)) errors.push('O ponto de início está fora do mapa.');
  if(!insideCell(map.goal.c,map.goal.r)) errors.push('A chegada está fora do mapa.');
  const blocked = (c,r)=> !!wallAt(c,r) || map.keyDoors.some(k=>sameCell(k.door,c,r));
  if(blocked(map.spawn.c,map.spawn.r)) errors.push('O início está bloqueado por uma parede ou porta.');
  if(blocked(map.goal.c,map.goal.r)) warnings.push('A chegada está coberta por uma parede ou porta.');
  for(const e of map.enemies){
    if(e.type==='guided' && (!Array.isArray(e.route) || e.route.length<2)) errors.push(`Inimigo guiado #${e.id} precisa de pelo menos 2 pontos.`);
    if(e.type==='moving' && Math.hypot(e.start.x-e.end.x,e.start.y-e.end.y)<1) warnings.push(`Inimigo móvel #${e.id} tem rota muito curta.`);
  }
  const cols=gridCols(), rows=gridRows();
  const passable=(c,r)=> c>=0&&r>=0&&c<cols&&r<rows&&!blocked(c,r);
  const queue=[[map.spawn.c,map.spawn.r]], seen=new Set([`${map.spawn.c},${map.spawn.r}`]);
  while(queue.length){
    const [c,r]=queue.shift();
    const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
    for(const [dx,dy] of dirs){ const nc=c+dx,nr=r+dy,k=`${nc},${nr}`; if(passable(nc,nr)&&!seen.has(k)){ seen.add(k); queue.push([nc,nr]); } }
    for(const p of map.portals){
      let target=null;
      if(sameCell(p.a,c,r)) target=p.b;
      else if(sameCell(p.b,c,r)) target=p.a;
      if(target){ const k=`${target.c},${target.r}`; if(passable(target.c,target.r)&&!seen.has(k)){ seen.add(k); queue.push([target.c,target.r]); } }
    }
  }
  if(!seen.has(`${map.goal.c},${map.goal.r}`)) warnings.push('A chegada não parece alcançável a partir do início (considerando paredes, portas fechadas e portais).');
  for(const cp of map.checkpoints){ if(!seen.has(`${cp.c},${cp.r}`)) warnings.push(`Checkpoint #${cp.id} pode estar inacessível.`); }
  for(const coin of map.coins){ if(!seen.has(`${coin.c},${coin.r}`)) warnings.push(`Moeda #${coin.id} pode estar inacessível.`); }
  return {errors,warnings};
}
function renderValidation(result){
  const total = result.errors.length + result.warnings.length;
  validationSummary.textContent = total===0 ? 'Mapa validado: nenhum problema encontrado.' : `Validação concluída: ${result.errors.length} erro(s), ${result.warnings.length} aviso(s).`;
  const lines=[];
  if(result.errors.length){ lines.push('Erros:'); result.errors.forEach((m,i)=>lines.push(`• ${m}`)); }
  if(result.warnings.length){ if(lines.length) lines.push(''); lines.push('Avisos:'); result.warnings.forEach((m,i)=>lines.push(`• ${m}`)); }
  validationList.textContent = lines.join('\n');
}
function runValidation(showStatus=true){ const result=validateMap(); renderValidation(result); if(showStatus) setStatus(result.errors.length ? 'Validação: há erros no mapa.' : result.warnings.length ? 'Validação concluída com avisos.' : 'Mapa validado com sucesso.'); return result; }
runValidationBtn && (runValidationBtn.onclick=()=>runValidation(true));
validateBtn && (validateBtn.onclick=()=>runValidation(true));
