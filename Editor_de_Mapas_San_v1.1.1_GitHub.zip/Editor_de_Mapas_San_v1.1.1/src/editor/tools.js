'use strict';

// Ferramentas de criação e eventos do canvas.
function resolveTarget(c,r,x,y){
  const w=wallAt(c,r); if(w) return {kind:'wall',id:w.id};
  const e=enemyAtPoint(x,y); if(e) return {kind:'enemy',id:e.id};
  const kd=map.keyDoors.find(k=>sameCell(k.door,c,r)); if(kd) return {kind:'door',id:kd.id};
  return null;
}
function occupied(c,r){
  return sameCell(map.spawn,c,r)||sameCell(map.goal,c,r)||!!wallAt(c,r)||
    map.checkpoints.some(q=>sameCell(q,c,r))||map.coins.some(q=>sameCell(q,c,r))||
    map.buttons.some(q=>sameCell(q.pos,c,r))||map.keyDoors.some(k=>sameCell(k.key,c,r)||sameCell(k.door,c,r))||
    map.portals.some(p=>sameCell(p.a,c,r)||sameCell(p.b,c,r));
}
function removeAt(p){
  const wallIds=map.walls.filter(w=>wallContains(w,p.c,p.r)).map(w=>w.id);
  // A rota de um inimigo guiado é apenas trajetória visual/lógica, não ocupação da célula.
  // Removemos inimigos somente quando o ponto-âncora deles está na célula clicada.
  // Isso permite que vários inimigos compartilhem/cruzem a mesma rota sem serem apagados.
  const enemyIds=map.enemies.filter(e=>{
    const a=enemyAnchor(e);
    return a && pointInCell(a.x,a.y,p.c,p.r);
  }).map(e=>e.id);
  const doorIds=map.keyDoors.filter(k=>sameCell(k.key,p.c,p.r)||sameCell(k.door,p.c,p.r)).map(k=>k.id);

  map.walls=map.walls.filter(w=>!wallIds.includes(w.id));
  map.enemies=map.enemies.filter(e=>!enemyIds.includes(e.id));
  map.checkpoints=map.checkpoints.filter(q=>!sameCell(q,p.c,p.r));
  map.coins=map.coins.filter(q=>!sameCell(q,p.c,p.r));
  map.portals=map.portals.filter(q=>!(sameCell(q.a,p.c,p.r)||sameCell(q.b,p.c,p.r)));
  map.keyDoors=map.keyDoors.filter(k=>!doorIds.includes(k.id));
  map.buttons=map.buttons.filter(b=>{
    if(sameCell(b.pos,p.c,p.r)) return false;
    return !(wallIds.includes(b.target?.id)||enemyIds.includes(b.target?.id)||doorIds.includes(b.target?.id));
  });
  clearSelection();
}

function clearPendingExcept(k=''){
  if(k!=='portal') pendingPortal=null;
  if(k!=='keydoor') pendingKey=null;
  if(k!=='button') pendingButton=null;
  if(!['horizontal','vertical','directional'].includes(k)) pendingPatrol=null;
  if(k!=='guided') pendingGuide=null;
  appendRouteTarget=null;
  updateGuideButtons();
}
function clearPending(){ clearPendingExcept(''); }
function updateGuideButtons(){ const on=!!pendingGuide; finishGuideBtn.disabled=!on; cancelGuideBtn.disabled=!on; }

function pointerPos(ev){
  const rect=canvas.getBoundingClientRect(), sx=canvas.width/rect.width, sy=canvas.height/rect.height;
  const x=clamp((ev.clientX-rect.left)*sx,0,Math.max(0,canvas.width-0.001));
  const y=clamp((ev.clientY-rect.top)*sy,0,Math.max(0,canvas.height-0.001));
  return {x,y,c:Math.floor(x/CELL),r:Math.floor(y/CELL)};
}
function findRouteNode(p){
  if(selected?.kind!=='enemy') return null;
  const e=map.enemies.find(q=>q.id===selected.id); if(!e||e.type!=='guided') return null;
  let best=null,bestD=12;
  e.route.forEach((q,i)=>{ const d=Math.hypot(q.x-p.x,q.y-p.y); if(d<=bestD){ best={enemy:e,index:i}; bestD=d; } });
  return best;
}

function place(p){
  if(tool==='select') return selectAt(p);
  if(tool==='erase'){ removeAt(p); commit(); draw(); return; }
  if(tool==='spawn'){ removeAt(p); map.spawn={c:p.c,r:p.r}; commit(); draw(); return; }
  if(tool==='goal'){ removeAt(p); map.goal={c:p.c,r:p.r}; commit(); draw(); return; }

  if(tool==='portal'){
    if(!pendingPortal){ removeAt(p); pendingPortal={c:p.c,r:p.r}; setStatus('Portal: escolha a segunda ponta.'); }
    else if(!sameCell(pendingPortal,p.c,p.r)){
      removeAt(p); map.portals.push({id:nextId(map.portals),a:{...pendingPortal},b:{c:p.c,r:p.r}});
      pendingPortal=null; commit(); updateStatus();
    }
    draw(); return;
  }
  if(tool==='keydoor'){
    if(!pendingKey){ removeAt(p); pendingKey={c:p.c,r:p.r}; setStatus('Chave posicionada. Agora escolha a porta.'); }
    else if(!sameCell(pendingKey,p.c,p.r)){
      removeAt(p); map.keyDoors.push({id:nextId(map.keyDoors),key:{...pendingKey},door:{c:p.c,r:p.r}});
      pendingKey=null; commit(); updateStatus();
    }
    draw(); return;
  }
  if(tool==='button'){
    if(!pendingButton){
      if(occupied(p.c,p.r)) removeAt(p);
      pendingButton={c:p.c,r:p.r}; setStatus('Botão posicionado. Clique em parede, inimigo ou porta.');
    }else{
      const target=resolveTarget(p.c,p.r,p.x,p.y);
      if(!target){ setStatus('Alvo inválido. Escolha parede, inimigo ou porta.'); return; }
      map.buttons.push({id:nextId(map.buttons),pos:{...pendingButton},target});
      pendingButton=null; commit(); updateStatus();
    }
    draw(); return;
  }
  if(['horizontal','vertical','directional'].includes(tool)){
    let q=snapPoint(p);
    if(!pendingPatrol){ pendingPatrol={tool,start:q}; setStatus('Patrulha: agora escolha o ponto Y.'); draw(); return; }
    if(tool==='horizontal') q={x:q.x,y:pendingPatrol.start.y};
    if(tool==='vertical') q={x:pendingPatrol.start.x,y:q.y};
    if(Math.hypot(q.x-pendingPatrol.start.x,q.y-pendingPatrol.start.y)<1){ setStatus('O ponto Y precisa ser diferente do X.'); return; }
    map.enemies.push({id:nextId(map.enemies),type:'moving',mode:'patrol',speed:clamp(Number(enemySpeed.value)||90,1,1000),start:{...pendingPatrol.start},end:q,angle:0});
    pendingPatrol=null; commit(); draw(); updateStatus(); return;
  }
  if(tool==='guided'){
    const q=snapPoint(p);
    if(!pendingGuide) pendingGuide=[q]; else pendingGuide.push(q);
    updateGuideButtons(); updateStatus(); draw(); return;
  }

  if(sameCell(map.spawn,p.c,p.r)||sameCell(map.goal,p.c,p.r)) return;
  removeAt(p);
  if(tool==='wall') map.walls.push({id:nextId(map.walls),c:p.c,r:p.r,w:1,h:1});
  if(tool==='static') map.enemies.push({id:nextId(map.enemies),type:'static',x:(p.c+.5)*CELL,y:(p.r+.5)*CELL});
  if(tool==='checkpoint') map.checkpoints.push({id:nextId(map.checkpoints),c:p.c,r:p.r});
  if(tool==='coin') map.coins.push({id:nextId(map.coins),c:p.c,r:p.r});
  commit(); draw();
}

finishGuideBtn.onclick=()=>{
  if(!pendingGuide) return;
  if(pendingGuide.length<2){ setStatus('A rota guiada precisa de pelo menos 2 pontos.'); return; }
  map.enemies.push({id:nextId(map.enemies),type:'guided',speed:clamp(Number(enemySpeed.value)||90,1,1000),route:pendingGuide.map(p=>({...p}))});
  pendingGuide=null; updateGuideButtons(); commit(); draw(); updateStatus();
};
cancelGuideBtn.onclick=()=>{ pendingGuide=null; updateGuideButtons(); draw(); updateStatus(); };

canvas.addEventListener('pointerdown',ev=>{
  if(mode!=='edit') return;
  const p=pointerPos(ev); dragging=true; canvas.setPointerCapture(ev.pointerId);

  if(tool==='select'&&appendRouteTarget){
    const e=map.enemies.find(q=>q.id===appendRouteTarget&&q.type==='guided');
    if(e){ e.route.push(snapPoint(p)); appendRouteTarget=null; commit(); showProperties(); draw(); setStatus('Ponto adicionado à rota.'); }
    return;
  }

  if(tool==='select'){
    const node=findRouteNode(p);
    if(node){ routeDrag={enemyId:node.enemy.id,index:node.index}; return; }
  }

  place(p);
});
canvas.addEventListener('pointermove',ev=>{
  const p=pointerPos(ev); cursorLabel.textContent=`x: ${Math.round(p.x)} • y: ${Math.round(p.y)}`;
  if(mode!=='edit'||!dragging) return;

  if(routeDrag){
    const e=map.enemies.find(q=>q.id===routeDrag.enemyId&&q.type==='guided');
    if(e){ e.route[routeDrag.index]=snapPoint(p); draw(); }
    return;
  }
  if(['wall','erase'].includes(tool)) place(p);
});
function endPointer(){
  dragging=false;
  if(routeDrag){ routeDrag=null; commit(); showProperties(); setStatus('Ponto da rota movido.'); }
}
canvas.addEventListener('pointerup',endPointer);
canvas.addEventListener('pointercancel',endPointer);

document.querySelectorAll('.tool').forEach(btn=>btn.onclick=()=>{
  tool=btn.dataset.tool; clearPendingExcept(tool); clearSelection();
  document.querySelectorAll('.tool').forEach(b=>b.classList.remove('active')); btn.classList.add('active');
  updateStatus(); draw();
});
